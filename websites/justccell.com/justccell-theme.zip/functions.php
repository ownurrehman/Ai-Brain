<?php
/**
 * Justccell theme bootstrap.
 *
 * @package Justccell
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

define('JUSTCCELL_VERSION', '0.1.0');
define('JUSTCCELL_DIR', get_template_directory());
define('JUSTCCELL_URI', get_template_directory_uri());

require_once JUSTCCELL_DIR . '/inc/setup.php';
require_once JUSTCCELL_DIR . '/inc/nav-fallback.php';
require_once JUSTCCELL_DIR . '/inc/assets.php';
require_once JUSTCCELL_DIR . '/inc/acf.php';
require_once JUSTCCELL_DIR . '/inc/woocommerce.php';
require_once JUSTCCELL_DIR . '/inc/inquiry.php';
