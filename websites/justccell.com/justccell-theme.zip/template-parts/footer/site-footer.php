<?php
/**
 * Site footer.
 *
 * @package Justccell
 */
declare(strict_types=1);
if (!defined('ABSPATH')) {
    exit;
}
?>
<footer class="site-footer">
    <div class="container site-footer__grid">
        <div class="site-footer__brand">
            <p class="site-footer__wordmark"><?php bloginfo('name'); ?></p>
            <p class="site-footer__tagline"><?php esc_html_e('Precision hardware for cannabis extracts.', 'justccell'); ?></p>
        </div>
        <nav class="site-footer__nav" aria-label="<?php esc_attr_e('Footer', 'justccell'); ?>">
            <?php
            wp_nav_menu([
                'theme_location' => 'footer',
                'container'      => false,
                'menu_class'     => 'footer-list',
                'fallback_cb'    => false,
            ]);
            ?>
        </nav>
        <div class="site-footer__cta">
            <p><?php esc_html_e('Test your extracts with Justccell hardware. Samples typically ship in 3–15 days.', 'justccell'); ?></p>
            <a class="btn btn--primary" href="<?php echo esc_url(justccell_inquiry_url()); ?>">
                <?php esc_html_e('Get samples & quotes', 'justccell'); ?>
            </a>
        </div>
    </div>
    <div class="site-footer__legal container">
        <p>&copy; <?php echo esc_html((string) gmdate('Y')); ?> <?php bloginfo('name'); ?></p>
        <?php
        wp_nav_menu([
            'theme_location' => 'legal',
            'container'      => false,
            'menu_class'     => 'footer-list footer-list--inline',
            'fallback_cb'    => false,
        ]);
        ?>
    </div>
</footer>
