<?php
/**
 * Primary site header + mega-nav shell.
 *
 * @package Justccell
 */
declare(strict_types=1);
if (!defined('ABSPATH')) {
    exit;
}
?>
<header class="site-header" data-header>
    <div class="site-header__bar container">
        <a class="site-header__brand" href="<?php echo esc_url(home_url('/')); ?>">
            <?php if (has_custom_logo()) : ?>
                <?php the_custom_logo(); ?>
            <?php else : ?>
                <span class="site-header__wordmark"><?php bloginfo('name'); ?></span>
            <?php endif; ?>
        </a>

        <nav class="site-header__nav" aria-label="<?php esc_attr_e('Primary', 'justccell'); ?>" data-nav>
            <?php
            wp_nav_menu([
                'theme_location' => 'primary',
                'container'      => false,
                'menu_class'     => 'nav-list',
                'fallback_cb'    => 'justccell_nav_fallback',
            ]);
            ?>
        </nav>

        <a class="btn btn--primary site-header__cta" href="<?php echo esc_url(justccell_inquiry_url()); ?>">
            <?php esc_html_e('Get samples & quotes', 'justccell'); ?>
        </a>

        <button class="site-header__toggle" type="button" data-nav-toggle aria-expanded="false" aria-controls="mobile-nav">
            <span class="visually-hidden"><?php esc_html_e('Menu', 'justccell'); ?></span>
            <span class="site-header__toggle-bars" aria-hidden="true"></span>
        </button>
    </div>
</header>
