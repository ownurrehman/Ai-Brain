<?php
/**
 * Theme supports, menus, permalinks.
 *
 * @package Justccell
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

add_action('after_setup_theme', static function (): void {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', [
        'height'      => 48,
        'width'       => 180,
        'flex-height' => true,
        'flex-width'  => true,
    ]);
    add_theme_support('html5', [
        'search-form',
        'gallery',
        'caption',
        'style',
        'script',
    ]);
    add_theme_support('align-wide');
    add_theme_support('responsive-embeds');
    add_theme_support('editor-styles');
    add_editor_style('assets/css/globals.css');

    register_nav_menus([
        'primary' => __('Primary', 'justccell'),
        'footer'  => __('Footer', 'justccell'),
        'legal'   => __('Legal', 'justccell'),
    ]);

    add_image_size('justccell-card', 720, 720, true);
    add_image_size('justccell-hero', 1920, 1080, true);
});

add_action('after_switch_theme', static function (): void {
    if (get_option('permalink_structure') !== '/%postname%/') {
        global $wp_rewrite;
        $wp_rewrite->set_permalink_structure('/%postname%/');
        $wp_rewrite->flush_rules(true);
    }

    $cats = [
        'all-in-ones' => __('All-In-Ones', 'justccell'),
        'cartridge'   => __('Cartridges', 'justccell'),
        'pod-system'  => __('Pod Systems', 'justccell'),
        'battery'     => __('510 Batteries', 'justccell'),
    ];

    if (taxonomy_exists('product_cat')) {
        foreach ($cats as $slug => $name) {
            if (!term_exists($slug, 'product_cat')) {
                wp_insert_term($name, 'product_cat', ['slug' => $slug]);
            }
        }
    }
});

add_filter('excerpt_length', static function (): int {
    return 24;
});

/**
 * Inquiry landing URL, optionally prefilled with a product SKU.
 */
function justccell_inquiry_url(string $sku = ''): string
{
    $url = home_url('/contact/');
    if ($sku !== '') {
        $url = add_query_arg('sku', rawurlencode($sku), $url);
    }
    return $url;
}
