<?php
/**
 * Homepage. Renders ACF flexible sections when present; otherwise a structural shell.
 *
 * @package Justccell
 */
declare(strict_types=1);
if (!defined('ABSPATH')) {
    exit;
}

get_header();

if (function_exists('have_rows') && have_rows('page_sections')) {
    justccell_render_flexible_sections();
} else {
    get_template_part('template-parts/flexible/hero');
    get_template_part('template-parts/flexible/product_grid');
    get_template_part('template-parts/flexible/technology');
    get_template_part('template-parts/flexible/cta_inquiry');
}

get_footer();
