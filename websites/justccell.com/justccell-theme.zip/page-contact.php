<?php
/**
 * Contact / B2B inquiry.
 *
 * @package Justccell
 */
declare(strict_types=1);
if (!defined('ABSPATH')) {
    exit;
}

get_header();

$status = sanitize_key((string) ($_GET['inquiry'] ?? ''));
$sku    = sanitize_text_field((string) ($_GET['sku'] ?? ''));
?>
<article class="page-article container">
    <header class="page-article__header">
        <h1 class="page-article__title"><?php esc_html_e('Get samples and quotes', 'justccell'); ?></h1>
        <p class="page-article__lede"><?php esc_html_e('Tell us about your extracts. Samples typically ship in 3–15 days.', 'justccell'); ?></p>
    </header>

    <?php if ($status === 'sent') : ?>
        <p class="form-notice form-notice--success" role="status"><?php esc_html_e('Request received. We will follow up shortly.', 'justccell'); ?></p>
    <?php elseif ($status === 'missing' || $status === 'invalid') : ?>
        <p class="form-notice form-notice--error" role="alert"><?php esc_html_e('Please complete name, email, and country.', 'justccell'); ?></p>
    <?php endif; ?>

    <?php get_template_part('template-parts/inquiry/form', null, ['sku' => $sku]); ?>
</article>
<?php
get_footer();
